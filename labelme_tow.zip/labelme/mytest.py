
def a():
    l = 1
    ll = 2
    lll = 3
    return l,ll,lll




c,cc = a()
print(c)